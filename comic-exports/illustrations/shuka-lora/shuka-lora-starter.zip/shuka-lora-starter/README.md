# シュカのキャラLoRA用 全身資料

トリガーは noctalith_shuka。登録画像 I000052 をもとに、正面・背面・左右側面・斜めからの全身画像10枚を作成した。背面の細部は参照画像から補った作画案。

train/ にPNG10枚と対応するキャプションを収録。dataset_sdxl.toml はSDXL向けで、image_dir は C:/Users/user/Downloads/shuka-lora-starter/shuka-lora-starter/train。その場所に展開したときに使える。別の場所へ展開した場合は、実際の train フォルダの絶対パスを設定する。学習は未実施。

train/ に顔のクローズアップを4枚追加。正面・斜め正面・左右側面が各1枚。全身10枚と合わせて画像14枚、キャプション14件を収録。
